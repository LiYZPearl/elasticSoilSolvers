The present FVM-based toolbox can be applied to soil consolidation analysis, WSSI analysis, and liquefacgtion assessment. 

An outline of the toolbox and an illustration of the systematic analysis procedure is presented in Fig. 2. in the paper
@article{li2019numerical,
  title={A numerical toolbox for wave-induced seabed response analysis around marine structures in the OpenFOAM{\textregistered} framework},
  author={Li, Yuzhu and Ong, Muk Chen and Tang, Tian},
  journal={Ocean Engineering},
  pages={106678},
  year={2019},
  publisher={Elsevier}
}

The present toolbox reads wave pressure data from a free-surface solver. There is no restriction on selecting the free-surface modeling tools. 
In the OpenFOAM CFD library, various solvers can be adopted, such as interFoam, toolboxes of waves2Foam (Jacobsen et al., 2012). In the work of \cite{li2019numerical}, the waves2Foam is adopted.

The work enviroment for the toolbox is foam-extend 3.1.

For tutorials and case studies, please go to https://github.com/LiYZPearl/tutorials.




